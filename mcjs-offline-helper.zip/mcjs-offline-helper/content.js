(function mcjsOfflineHelper() {
    // ============================================================
    // 配置
    // ============================================================
    const VERSION_MAP = {
        '1.8.8': '1.8.8',
        '1.8.8wasm': '1.8.8wasm',
        '1.12.2': '1.12.2',
        '1.12.2wasm': '1.12.2wasm'
    };

    // 两个按钮的链接模板
    const BUTTONS = [
        {
            text: '个人维护版本',
            urlTemplate: 'https://sltlele.github.io/mcjs-{version}/'   // ✅ 已改为 sltlele.github.io/mcjs-版本号
        },
        {
            text: '离线版本下载',
            urlTemplate: 'https://github.com/sltlele/mcjs-{version}'    // ✅ 保持不变
        }
    ];

    const ALLOWED_DOMAINS = [
        'mcjs.cc',
        'play.mcjs.144449.xyz',
        'playmcjscc.pages.dev',
        'ipv6.mcjs.cc'
    ];

    // ============================================================
    // 工具函数
    // ============================================================
    function getVersionFromURL(url) {
        try {
            const urlObj = new URL(url);
            const hostname = urlObj.hostname;
            const pathname = urlObj.pathname;
            if (!ALLOWED_DOMAINS.some(d => hostname === d || hostname.endsWith('.' + d))) {
                return null;
            }
            const segments = pathname.replace(/^\/+/, '').split('/');
            const versionCandidate = segments[0] || '';
            if (VERSION_MAP[versionCandidate]) {
                return VERSION_MAP[versionCandidate];
            }
            return null;
        } catch (e) {
            return null;
        }
    }

    // ============================================================
    // 功能一：在 mcjs.cc/ 主页添加两个离线下载按钮
    // ============================================================
    function addOfflineButtons() {
        const currentPath = window.location.pathname;
        if (currentPath !== '/' && currentPath !== '/index.html' && currentPath !== '') {
            return;
        }

        const cards = document.querySelectorAll('.card');
        if (cards.length < 4) {
            console.warn('未找到足够的卡片');
            return;
        }

        const versionOrder = ['1.8.8', '1.8.8wasm', '1.12.2', '1.12.2wasm'];

        cards.forEach((card, index) => {
            if (index >= versionOrder.length) return;
            const version = versionOrder[index];
            if (card.querySelector('.mcjs-offline-buttons')) return;

            const existingBtns = card.querySelectorAll('.btn');
            if (existingBtns.length === 0) return;
            const lastBtn = existingBtns[existingBtns.length - 1];

            const container = document.createElement('div');
            container.className = 'mcjs-offline-buttons';
            container.style.cssText = `
                display: flex;
                gap: 8px;
                flex-wrap: wrap;
                margin-top: 8px;
            `;

            BUTTONS.forEach(btnConfig => {
                const url = btnConfig.urlTemplate.replace('{version}', version);
                const a = document.createElement('a');
                a.className = 'btn';
                a.textContent = btnConfig.text;
                a.href = url;
                a.target = '_blank';
                a.style.cssText = `
                    font-weight: normal;
                    font-size: 13px;
                    padding: 8px 12px;
                    background: #2c3e50;
                    color: #fff;
                    text-decoration: none;
                    border-radius: 0;
                    transition: background 0.2s;
                    flex: 1 1 auto;
                    text-align: center;
                `;
                a.onmouseover = () => { a.style.background = '#1a252f'; };
                a.onmouseout = () => { a.style.background = '#2c3e50'; };
                container.appendChild(a);
            });

            lastBtn.parentNode.insertBefore(container, lastBtn.nextSibling);
        });

        console.log('✅ MCJS 离线下载按钮已添加');
    }

    // ============================================================
    // 功能二：Lele 导航按钮（主页突出 + 游戏页面浮动）
    // ============================================================
    function addLeleNav() {
        const isHome = window.location.pathname === '/' || window.location.pathname === '/index.html' || window.location.pathname === '';
        const url = 'https://Lelegame.dpdns.org';

        if (isHome) {
            // ===== 主页：在 hero 区域下方添加醒目标志 =====
            if (document.querySelector('.mcjs-lele-nav')) return;

            const hero = document.querySelector('.hero');
            if (!hero) return;

            const container = document.createElement('div');
            container.className = 'mcjs-lele-nav';
            container.style.cssText = `
                text-align: center;
                margin: 16px auto 8px;
                padding: 10px 20px;
                background: linear-gradient(135deg, #ff8c00, #ff6600);
                border-radius: 8px;
                max-width: 300px;
                box-shadow: 0 4px 20px rgba(255, 102, 0, 0.4);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
                cursor: pointer;
            `;
            container.onmouseover = () => {
                container.style.transform = 'scale(1.05)';
                container.style.boxShadow = '0 6px 30px rgba(255, 102, 0, 0.6)';
            };
            container.onmouseout = () => {
                container.style.transform = 'scale(1)';
                container.style.boxShadow = '0 4px 20px rgba(255, 102, 0, 0.4)';
            };

            const link = document.createElement('a');
            link.href = url;
            link.target = '_blank';
            link.textContent = '🌐 Lele 导航';
            link.style.cssText = `
                color: #fff;
                font-size: 22px;
                font-weight: bold;
                text-decoration: none;
                letter-spacing: 2px;
                display: block;
            `;
            container.appendChild(link);

            // 插入到 hero 后面
            hero.parentNode.insertBefore(container, hero.nextSibling);
            console.log('✅ Lele 导航已添加到主页');
        } else {
            // ===== 游戏页面：浮动小按钮（不打扰游戏） =====
            if (document.querySelector('.mcjs-lele-nav-float')) return;

            const btn = document.createElement('div');
            btn.className = 'mcjs-lele-nav-float';
            btn.style.cssText = `
                position: fixed;
                bottom: 30px;
                left: 30px;
                z-index: 999998;
                background: rgba(255, 102, 0, 0.75);
                color: #fff;
                padding: 8px 16px;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
                cursor: pointer;
                box-shadow: 0 2px 12px rgba(0,0,0,0.3);
                transition: all 0.3s ease;
                backdrop-filter: blur(4px);
                font-family: system-ui, sans-serif;
                user-select: none;
                border: 1px solid rgba(255,255,255,0.2);
            `;
            btn.textContent = '🌐 Lele 导航';
            btn.onmouseover = () => {
                btn.style.background = 'rgba(255, 102, 0, 0.95)';
                btn.style.transform = 'scale(1.1)';
            };
            btn.onmouseout = () => {
                btn.style.background = 'rgba(255, 102, 0, 0.75)';
                btn.style.transform = 'scale(1)';
            };
            btn.onclick = () => {
                window.open(url, '_blank');
            };

            document.body.appendChild(btn);
            console.log('✅ Lele 导航浮动按钮已添加到游戏页面');
        }
    }

    // ============================================================
    // 功能三：开发者标注（页面最底部）
    // ============================================================
    function addDeveloperCredit() {
        if (document.querySelector('.mcjs-developer-credit')) return;

        const isHome = window.location.pathname === '/' || window.location.pathname === '/index.html' || window.location.pathname === '';

        if (isHome) {
            // ===== 主页：放在页脚 =====
            const footer = document.querySelector('footer');
            if (!footer) return;

            const credit = document.createElement('div');
            credit.className = 'mcjs-developer-credit';
            credit.style.cssText = `
                margin-top: 12px;
                padding-top: 10px;
                border-top: 1px solid rgba(0,0,0,0.08);
                font-size: 13px;
                color: #888;
                letter-spacing: 0.5px;
            `;
            credit.innerHTML = `插件开发者：<strong style="color: #ff6600;">SltLele</strong>`;
            footer.appendChild(credit);
            console.log('✅ 开发者标注已添加到主页页脚');
        } else {
            // ===== 游戏页面：固定底部居中（半透明，不打扰） =====
            const credit = document.createElement('div');
            credit.className = 'mcjs-developer-credit';
            credit.style.cssText = `
                position: fixed;
                bottom: 10px;
                left: 50%;
                transform: translateX(-50%);
                z-index: 999997;
                background: rgba(0, 0, 0, 0.4);
                backdrop-filter: blur(4px);
                color: rgba(255,255,255,0.6);
                font-size: 12px;
                padding: 4px 16px;
                border-radius: 12px;
                font-family: system-ui, sans-serif;
                letter-spacing: 0.5px;
                pointer-events: none;
                user-select: none;
                border: 1px solid rgba(255,255,255,0.05);
            `;
            credit.innerHTML = `插件开发者：<strong style="color: #ff8844;">SltLele</strong>`;
            document.body.appendChild(credit);
            console.log('✅ 开发者标注已添加到游戏页面底部');
        }
    }

    // ============================================================
    // 功能四：游戏页面可拖动蓝色小球（跳转到个人维护版本）
    // ============================================================
    function createFloatingBall(version) {
        if (document.querySelector('.mcjs-download-ball')) return;

        const offlineUrl = 'https://sltlele.github.io/mcjs-' + version + '/';

        const ball = document.createElement('div');
        ball.className = 'mcjs-download-ball';
        ball.dataset.version = version;
        ball.dataset.url = offlineUrl;
        ball.dataset.state = 'expanded';

        Object.assign(ball.style, {
            position: 'fixed',
            right: '30px',
            top: '100px',
            width: '80px',
            height: '80px',
            borderRadius: '50%',
            background: 'radial-gradient(circle at 30% 30%, #4a9eff, #1a6bc4)',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '14px',
            fontWeight: 'bold',
            textAlign: 'center',
            cursor: 'grab',
            zIndex: '999999',
            boxShadow: '0 4px 20px rgba(26, 107, 196, 0.5)',
            userSelect: 'none',
            WebkitUserSelect: 'none',
            fontFamily: 'system-ui, sans-serif',
            lineHeight: '1.3',
            transition: 'width 0.3s ease, height 0.3s ease, border-radius 0.3s ease, right 0.3s ease, top 0.3s ease, left 0.3s ease, bottom 0.3s ease, box-shadow 0.3s ease',
            touchAction: 'none',
            pointerEvents: 'auto'
        });

        const text = document.createElement('span');
        text.textContent = '下载此游戏';
        text.style.cssText = `
            pointer-events: none;
            font-size: 14px;
            text-shadow: 0 1px 4px rgba(0,0,0,0.3);
            padding: 4px;
        `;
        ball.appendChild(text);

        const arrow = document.createElement('span');
        arrow.className = 'mcjs-ball-arrow';
        arrow.textContent = '▶';
        arrow.style.cssText = `
            display: none;
            pointer-events: none;
            font-size: 20px;
            color: #fff;
            text-shadow: 0 1px 6px rgba(0,0,0,0.5);
        `;
        ball.appendChild(arrow);

        document.body.appendChild(ball);

        // ---- 拖动逻辑 ----
        let isDragging = false;
        let offsetX, offsetY;

        function setPosition(left, top) {
            const maxX = window.innerWidth - ball.offsetWidth;
            const maxY = window.innerHeight - ball.offsetHeight;
            left = Math.max(0, Math.min(left, maxX));
            top = Math.max(0, Math.min(top, maxY));
            ball.style.left = left + 'px';
            ball.style.top = top + 'px';
            ball.style.right = 'auto';
            ball.style.bottom = 'auto';
        }

        function snapToEdge(left, top) {
            const bw = window.innerWidth;
            const bh = window.innerHeight;
            const w = ball.offsetWidth || 80;
            const h = ball.offsetHeight || 80;
            const padding = 20;

            const distLeft = left;
            const distRight = bw - left - w;
            const distTop = top;
            const distBottom = bh - top - h;
            const minDist = Math.min(distLeft, distRight, distTop, distBottom);

            ball.dataset.state = 'expanded';
            ball.style.width = '80px';
            ball.style.height = '80px';
            ball.style.borderRadius = '50%';
            ball.style.boxShadow = '0 4px 20px rgba(26, 107, 196, 0.5)';
            text.style.display = 'block';
            arrow.style.display = 'none';

            let snapLeft, snapTop;

            if (minDist === distLeft) {
                snapLeft = padding;
                snapTop = Math.max(padding, Math.min(top, bh - h - padding));
                ball.dataset.state = 'collapsed';
                ball.style.width = '24px';
                ball.style.height = '80px';
                ball.style.borderRadius = '0 12px 12px 0';
                ball.style.boxShadow = '0 4px 20px rgba(26, 107, 196, 0.4)';
                text.style.display = 'none';
                arrow.style.display = 'block';
                arrow.textContent = '▶';
                arrow.style.marginLeft = '2px';
            } else if (minDist === distRight) {
                snapLeft = bw - w - padding;
                snapTop = Math.max(padding, Math.min(top, bh - h - padding));
                ball.dataset.state = 'collapsed';
                ball.style.width = '24px';
                ball.style.height = '80px';
                ball.style.borderRadius = '12px 0 0 12px';
                ball.style.boxShadow = '0 4px 20px rgba(26, 107, 196, 0.4)';
                text.style.display = 'none';
                arrow.style.display = 'block';
                arrow.textContent = '◀';
                arrow.style.marginRight = '2px';
            } else if (minDist === distTop) {
                snapLeft = Math.max(padding, Math.min(left, bw - w - padding));
                snapTop = padding;
                ball.dataset.state = 'collapsed';
                ball.style.width = '80px';
                ball.style.height = '24px';
                ball.style.borderRadius = '0 0 12px 12px';
                ball.style.boxShadow = '0 4px 20px rgba(26, 107, 196, 0.4)';
                text.style.display = 'none';
                arrow.style.display = 'block';
                arrow.textContent = '▼';
            } else {
                snapLeft = Math.max(padding, Math.min(left, bw - w - padding));
                snapTop = bh - h - padding;
                ball.dataset.state = 'collapsed';
                ball.style.width = '80px';
                ball.style.height = '24px';
                ball.style.borderRadius = '12px 12px 0 0';
                ball.style.boxShadow = '0 4px 20px rgba(26, 107, 196, 0.4)';
                text.style.display = 'none';
                arrow.style.display = 'block';
                arrow.textContent = '▲';
            }
            setPosition(snapLeft, snapTop);
        }

        // 鼠标事件
        ball.addEventListener('mousedown', function(e) {
            if (e.button !== 0) return;
            isDragging = true;
            const rect = ball.getBoundingClientRect();
            offsetX = e.clientX - rect.left;
            offsetY = e.clientY - rect.top;
            ball.style.cursor = 'grabbing';
            ball.style.transition = 'none';
            if (ball.dataset.state === 'collapsed') {
                ball.dataset.state = 'expanded';
                ball.style.width = '80px';
                ball.style.height = '80px';
                ball.style.borderRadius = '50%';
                ball.style.boxShadow = '0 4px 20px rgba(26, 107, 196, 0.5)';
                text.style.display = 'block';
                arrow.style.display = 'none';
                const r = ball.getBoundingClientRect();
                setPosition(r.left, r.top);
            }
            e.preventDefault();
        });

        document.addEventListener('mousemove', function(e) {
            if (!isDragging) return;
            const newLeft = e.clientX - offsetX;
            const newTop = e.clientY - offsetY;
            setPosition(newLeft, newTop);
            e.preventDefault();
        });

        document.addEventListener('mouseup', function(e) {
            if (isDragging) {
                isDragging = false;
                ball.style.cursor = 'grab';
                requestAnimationFrame(() => {
                    ball.style.transition = 'width 0.3s ease, height 0.3s ease, border-radius 0.3s ease, right 0.3s ease, top 0.3s ease, left 0.3s ease, bottom 0.3s ease, box-shadow 0.3s ease';
                });
                const rect = ball.getBoundingClientRect();
                snapToEdge(rect.left, rect.top);
            }
        });

        ball.addEventListener('mouseenter', function() {
            if (ball.dataset.state === 'collapsed') {
                ball.dataset.state = 'expanded';
                ball.style.width = '80px';
                ball.style.height = '80px';
                ball.style.borderRadius = '50%';
                ball.style.boxShadow = '0 4px 20px rgba(26, 107, 196, 0.6)';
                text.style.display = 'block';
                arrow.style.display = 'none';
                const rect = ball.getBoundingClientRect();
                const maxX = window.innerWidth - 80;
                const maxY = window.innerHeight - 80;
                let left = Math.max(0, Math.min(rect.left, maxX));
                let top = Math.max(0, Math.min(rect.top, maxY));
                setPosition(left, top);
            }
        });

        ball.addEventListener('mouseleave', function() {
            if (!isDragging && ball.dataset.state === 'expanded') {
                const rect = ball.getBoundingClientRect();
                snapToEdge(rect.left, rect.top);
            }
        });

        ball.addEventListener('click', function(e) {
            if (isDragging) return;
            if (ball.dataset.state === 'collapsed') return;
            const url = ball.dataset.url;
            if (url) window.open(url, '_blank');
        });

        // 触摸支持
        let touchOffsetX, touchOffsetY;
        let isTouching = false;
        ball.addEventListener('touchstart', function(e) {
            const touch = e.touches[0];
            const rect = ball.getBoundingClientRect();
            touchOffsetX = touch.clientX - rect.left;
            touchOffsetY = touch.clientY - rect.top;
            isTouching = true;
            ball.style.transition = 'none';
            if (ball.dataset.state === 'collapsed') {
                ball.dataset.state = 'expanded';
                ball.style.width = '80px';
                ball.style.height = '80px';
                ball.style.borderRadius = '50%';
                ball.style.boxShadow = '0 4px 20px rgba(26, 107, 196, 0.5)';
                text.style.display = 'block';
                arrow.style.display = 'none';
                const r = ball.getBoundingClientRect();
                setPosition(r.left, r.top);
            }
            e.preventDefault();
        }, { passive: false });

        document.addEventListener('touchmove', function(e) {
            if (!isTouching) return;
            const touch = e.touches[0];
            const newLeft = touch.clientX - touchOffsetX;
            const newTop = touch.clientY - touchOffsetY;
            setPosition(newLeft, newTop);
            e.preventDefault();
        }, { passive: false });

        document.addEventListener('touchend', function(e) {
            if (isTouching) {
                isTouching = false;
                ball.style.transition = 'width 0.3s ease, height 0.3s ease, border-radius 0.3s ease, right 0.3s ease, top 0.3s ease, left 0.3s ease, bottom 0.3s ease, box-shadow 0.3s ease';
                const rect = ball.getBoundingClientRect();
                snapToEdge(rect.left, rect.top);
            }
        }, { passive: false });

        console.log(`✅ 下载小球已创建，版本: ${version}，点击跳转: ${offlineUrl}`);
    }

    // ============================================================
    // 主逻辑
    // ============================================================
    function init() {
        const url = window.location.href;
        const version = getVersionFromURL(url);
        const isHome = window.location.pathname === '/' || window.location.pathname === '/index.html' || window.location.pathname === '';

        if (version) {
            // 游戏页面
            createFloatingBall(version);
            addLeleNav();           // 浮动小按钮
            addDeveloperCredit();   // 底部开发者标注
        } else if (isHome && (window.location.hostname === 'mcjs.cc' || window.location.hostname === 'www.mcjs.cc')) {
            // 主页
            addOfflineButtons();
            addLeleNav();           // 突出显示
            addDeveloperCredit();   // 页脚开发者标注
        }
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        init();
    } else {
        document.addEventListener('DOMContentLoaded', init);
    }

    // 监听 SPA 路由变化
    let lastUrl = window.location.href;
    setInterval(() => {
        if (window.location.href !== lastUrl) {
            lastUrl = window.location.href;
            const version = getVersionFromURL(window.location.href);
            if (version && !document.querySelector('.mcjs-download-ball')) {
                createFloatingBall(version);
            }
            // 对于非游戏页面，如果还没添加相关元素，可以再执行一次
            const isHome = window.location.pathname === '/' || window.location.pathname === '/index.html' || window.location.pathname === '';
            if (isHome && !document.querySelector('.mcjs-lele-nav')) {
                addLeleNav();
            }
            if (isHome && !document.querySelector('.mcjs-developer-credit')) {
                addDeveloperCredit();
            }
        }
    }, 1000);

})();